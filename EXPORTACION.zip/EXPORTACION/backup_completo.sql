-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         12.2.2-MariaDB - MariaDB Server
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.14.0.7165
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para proyecto_smorgas
CREATE DATABASE IF NOT EXISTS `proyecto_smorgas` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `proyecto_smorgas`;

-- Volcando estructura para función proyecto_smorgas.fn_obtener_fecha
DELIMITER //
CREATE FUNCTION `fn_obtener_fecha`(p_dia TINYINT, p_mes TINYINT, p_anio SMALLINT) RETURNS int(10) unsigned
    MODIFIES SQL DATA
BEGIN
    DECLARE v_id INT UNSIGNED DEFAULT NULL;

    SELECT ID_Fecha INTO v_id
      FROM tbl_fecha
     WHERE Dia = p_dia AND Mes = p_mes AND Anio = p_anio
     LIMIT 1;

    IF v_id IS NULL THEN
        INSERT INTO tbl_fecha(Dia, Mes, Anio) VALUES (p_dia, p_mes, p_anio);
        SET v_id = LAST_INSERT_ID();
    END IF;

    RETURN v_id;
END//
DELIMITER ;

-- Volcando estructura para procedimiento proyecto_smorgas.sp_nueva_compra
DELIMITER //
CREATE PROCEDURE `sp_nueva_compra`(
    IN  p_modo_entrega INT UNSIGNED,
    IN  p_id_mesa      INT UNSIGNED,
    OUT p_folio        INT UNSIGNED
)
BEGIN
    DECLARE v_id_fecha INT UNSIGNED;

    -- Reutiliza la función para obtener/crear la fecha
    SET v_id_fecha = fn_obtener_fecha(
        DAY(NOW()), MONTH(NOW()), YEAR(NOW())
    );

    INSERT INTO tbl_compra (
        Importe_Total, Cantidad_Total, Hora,
        ID_Modo_Entrega, ID_Fecha, ID_Mesa
    ) VALUES (
        0, 0, NOW(),
        p_modo_entrega, v_id_fecha, p_id_mesa
    );

    SET p_folio = LAST_INSERT_ID();
END//
DELIMITER ;

-- Volcando estructura para tabla proyecto_smorgas.tbl_compra
CREATE TABLE IF NOT EXISTS `tbl_compra` (
  `Folio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Importe_Total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `Cantidad_Total` int(10) unsigned NOT NULL DEFAULT 0,
  `Hora` datetime DEFAULT NULL,
  `ID_Modo_Entrega` int(10) unsigned NOT NULL,
  `ID_Fecha` int(10) unsigned NOT NULL,
  `ID_Mesa` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Folio`),
  KEY `idx_compra_modo` (`ID_Modo_Entrega`),
  KEY `idx_compra_fecha` (`ID_Fecha`),
  KEY `idx_compra_mesa` (`ID_Mesa`),
  CONSTRAINT `fk_compra_fecha` FOREIGN KEY (`ID_Fecha`) REFERENCES `tbl_fecha` (`ID_Fecha`),
  CONSTRAINT `fk_compra_mesa` FOREIGN KEY (`ID_Mesa`) REFERENCES `tbl_mesa` (`ID_Mesa`),
  CONSTRAINT `fk_compra_modo` FOREIGN KEY (`ID_Modo_Entrega`) REFERENCES `tbl_modo_entrega` (`ID_Modo_Entrega`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla proyecto_smorgas.tbl_compra: ~49 rows (aproximadamente)
DELETE FROM `tbl_compra`;
INSERT INTO `tbl_compra` (`Folio`, `Importe_Total`, `Cantidad_Total`, `Hora`, `ID_Modo_Entrega`, `ID_Fecha`, `ID_Mesa`) VALUES
	(5, 100.86, 1, '2026-03-13 08:00:00', 1, 1, 107),
	(6, 900.00, 12, '2026-03-13 08:00:00', 1, 1, 105),
	(7, 20.00, 1, '2026-03-13 08:00:00', 2, 1, 105),
	(8, 20.00, 1, '2026-03-13 08:00:00', 1, 1, 105),
	(9, 20.00, 1, '2026-03-13 08:00:00', 1, 1, 100),
	(25, 120.00, 6, '2026-03-13 08:00:00', 1, 1, 104),
	(26, 140.09, 7, '2026-03-13 08:00:00', 1, 2, 100),
	(28, 3004.22, 112, '2026-03-13 08:00:00', 1, 3, 101),
	(31, 20.00, 1, '2026-03-13 12:09:54', 1, 6, 102),
	(32, 1440.24, 12, '2026-03-13 12:12:37', 1, 6, 103),
	(33, 30.00, 1, '2026-03-13 16:07:08', 2, 19, 103),
	(34, 3680.00, 69, '2026-03-13 16:08:23', 1, 19, 103),
	(35, 48250.00, 550, '2026-03-13 16:13:26', 2, 19, 101),
	(36, 1250.00, 50, '2026-03-13 16:16:29', 2, 19, 105),
	(37, 1250.00, 50, '2026-03-13 16:16:43', 2, 19, 100),
	(38, 3000.00, 50, '2026-03-13 16:16:59', 2, 19, 102),
	(39, 1000.00, 50, '2026-03-13 16:17:10', 2, 19, 103),
	(40, 1250.00, 50, '2026-03-13 16:17:22', 2, 19, 103),
	(41, 110.00, 1, '2026-03-13 16:17:30', 2, 19, 103),
	(42, 1500.00, 50, '2026-03-13 16:17:39', 2, 19, 103),
	(43, 49000.00, 500, '2026-03-13 16:18:20', 2, 19, 104),
	(44, 8500.00, 100, '2026-03-13 16:22:33', 2, 19, 104),
	(45, 21750.00, 200, '2026-03-13 16:23:35', 1, 19, 103),
	(46, 6500.00, 200, '2026-03-13 16:26:21', 1, 19, 104),
	(47, 4025.00, 101, '2026-03-13 16:30:50', 2, 19, 103),
	(48, 400.00, 5, '2026-03-17 16:18:53', 1, 20, 103),
	(52, 22500.00, 200, '2026-03-17 17:12:03', 2, 20, 102),
	(53, 60.00, 1, '2026-03-17 17:12:30', 1, 20, 104),
	(54, 80.00, 1, '2026-03-17 17:12:37', 1, 20, 102),
	(55, 80.00, 1, '2026-03-17 17:12:43', 1, 20, 102),
	(56, 60.00, 1, '2026-03-17 17:13:00', 1, 20, 103),
	(57, 40.00, 1, '2026-03-17 17:13:07', 1, 20, 104),
	(58, 180.00, 1, '2026-03-17 17:13:19', 1, 20, 103),
	(59, 40.00, 1, '2026-03-17 17:13:32', 1, 20, 103),
	(60, 60.00, 1, '2026-03-17 17:13:39', 1, 20, 104),
	(61, 40.00, 1, '2026-03-17 17:13:46', 1, 20, 105),
	(62, 60.00, 1, '2026-03-17 17:13:53', 1, 20, 104),
	(63, 80.00, 1, '2026-03-17 17:13:59', 1, 20, 103),
	(64, 80.00, 1, '2026-03-17 17:14:05', 1, 20, 103),
	(65, 150.00, 1, '2026-03-17 17:14:15', 1, 20, 104),
	(66, 100.00, 1, '2026-03-17 17:14:22', 1, 20, 104),
	(67, 100.00, 1, '2026-03-17 17:14:31', 1, 20, 104),
	(68, 4590.00, 51, '2026-03-17 17:14:43', 1, 20, 104),
	(69, 90.00, 1, '2026-03-17 17:14:51', 1, 20, 105),
	(70, 90.00, 1, '2026-03-17 17:14:58', 1, 20, 103),
	(71, 65.00, 1, '2026-03-17 17:15:07', 1, 20, 102),
	(72, 9500.00, 100, '2026-03-17 17:15:25', 1, 20, 104),
	(73, 65.00, 1, '2026-03-17 17:15:31', 1, 20, 103),
	(75, 480.00, 6, '2026-05-14 21:06:00', 2, 23, 108);

-- Volcando estructura para tabla proyecto_smorgas.tbl_detalle
CREATE TABLE IF NOT EXISTS `tbl_detalle` (
  `ID_Detalle` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Folio` int(10) unsigned NOT NULL,
  `ID_Producto` int(10) unsigned NOT NULL,
  `Cantidad` int(10) unsigned NOT NULL DEFAULT 1,
  `Precio_Unit` decimal(10,2) NOT NULL DEFAULT 0.00,
  `Subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`ID_Detalle`),
  KEY `idx_detalle_folio` (`Folio`),
  KEY `idx_detalle_producto` (`ID_Producto`),
  CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`Folio`) REFERENCES `tbl_compra` (`Folio`) ON DELETE CASCADE,
  CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`ID_Producto`) REFERENCES `tbl_producto` (`ID_Producto`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla proyecto_smorgas.tbl_detalle: ~91 rows (aproximadamente)
DELETE FROM `tbl_detalle`;
INSERT INTO `tbl_detalle` (`ID_Detalle`, `Folio`, `ID_Producto`, `Cantidad`, `Precio_Unit`, `Subtotal`) VALUES
	(8, 5, 1013, 1, 100.86, 100.86),
	(9, 6, 1036, 6, 20.00, 0.00),
	(10, 6, 1008, 6, 150.00, 900.00),
	(11, 7, 1030, 1, 20.00, 0.00),
	(12, 8, 1030, 1, 20.00, 0.00),
	(13, 9, 1030, 1, 20.00, 0.00),
	(31, 25, 1029, 4, 20.00, 80.00),
	(32, 25, 1030, 1, 20.00, 20.00),
	(33, 25, 1029, 1, 20.00, 20.00),
	(34, 26, 1030, 1, 20.09, 20.09),
	(35, 26, 1030, 6, 20.00, 120.00),
	(38, 28, 1031, 50, 30.00, 1500.00),
	(39, 28, 1008, 1, 0.01, 0.01),
	(40, 28, 1021, 1, 0.01, 0.01),
	(41, 28, 1014, 10, 0.42, 4.20),
	(42, 28, 1031, 50, 30.00, 1500.00),
	(51, 31, 1030, 1, 20.00, 0.00),
	(52, 32, 1000, 12, 120.02, 1440.24),
	(53, 33, 1031, 1, 30.00, 0.00),
	(54, 34, 1036, 46, 20.00, 0.00),
	(55, 34, 1002, 23, 120.00, 0.00),
	(56, 35, 1028, 50, 30.00, 0.00),
	(57, 35, 1004, 50, 120.00, 0.00),
	(58, 35, 1019, 50, 180.00, 0.00),
	(59, 35, 1010, 50, 65.00, 0.00),
	(60, 35, 1030, 50, 20.00, 0.00),
	(61, 35, 1035, 50, 10.00, 0.00),
	(62, 35, 1000, 50, 120.00, 0.00),
	(63, 35, 1029, 50, 20.00, 0.00),
	(64, 35, 1009, 50, 100.00, 0.00),
	(65, 35, 1019, 50, 180.00, 0.00),
	(66, 35, 1017, 50, 120.00, 0.00),
	(67, 36, 1034, 50, 25.00, 0.00),
	(68, 37, 1034, 50, 25.00, 0.00),
	(69, 38, 1026, 50, 60.00, 0.00),
	(70, 39, 1036, 50, 20.00, 0.00),
	(71, 40, 1034, 50, 25.00, 0.00),
	(72, 41, 1005, 1, 110.00, 0.00),
	(73, 42, 1031, 50, 30.00, 0.00),
	(74, 43, 1022, 50, 40.00, 0.00),
	(75, 43, 1006, 50, 110.00, 0.00),
	(76, 43, 1018, 50, 150.00, 0.00),
	(77, 43, 1012, 50, 100.00, 0.00),
	(78, 43, 1030, 50, 20.00, 0.00),
	(79, 43, 1000, 50, 120.00, 0.00),
	(80, 43, 1020, 50, 170.00, 0.00),
	(81, 43, 1015, 50, 100.00, 0.00),
	(82, 43, 1025, 50, 50.00, 0.00),
	(83, 43, 1002, 50, 120.00, 0.00),
	(84, 44, 1026, 50, 60.00, 0.00),
	(85, 44, 1005, 50, 110.00, 0.00),
	(86, 45, 1032, 50, 25.00, 0.00),
	(87, 45, 1006, 50, 110.00, 0.00),
	(88, 45, 1019, 50, 180.00, 0.00),
	(89, 45, 1017, 50, 120.00, 0.00),
	(90, 46, 1028, 50, 30.00, 0.00),
	(91, 46, 1028, 50, 30.00, 0.00),
	(92, 46, 1024, 50, 40.00, 0.00),
	(93, 46, 1031, 50, 30.00, 0.00),
	(94, 47, 1034, 1, 25.00, 0.00),
	(95, 47, 1026, 50, 60.00, 0.00),
	(96, 47, 1036, 50, 20.00, 0.00),
	(97, 48, 1027, 5, 80.00, 0.00),
	(101, 52, 1036, 50, 20.00, 0.00),
	(102, 52, 1008, 50, 150.00, 0.00),
	(103, 52, 1019, 50, 180.00, 0.00),
	(104, 52, 1015, 50, 100.00, 0.00),
	(105, 53, 1026, 1, 60.00, 0.00),
	(106, 54, 1027, 1, 80.00, 0.00),
	(107, 55, 1027, 1, 80.00, 0.00),
	(108, 56, 1026, 1, 60.00, 0.00),
	(109, 57, 1023, 1, 40.00, 0.00),
	(110, 58, 1019, 1, 180.00, 0.00),
	(111, 59, 1023, 1, 40.00, 0.00),
	(112, 60, 1026, 1, 60.00, 0.00),
	(113, 61, 1023, 1, 40.00, 0.00),
	(114, 62, 1026, 1, 60.00, 0.00),
	(115, 63, 1027, 1, 80.00, 0.00),
	(116, 64, 1027, 1, 80.00, 0.00),
	(117, 65, 1018, 1, 150.00, 0.00),
	(118, 66, 1015, 1, 100.00, 0.00),
	(119, 67, 1012, 1, 100.00, 0.00),
	(120, 68, 1014, 1, 90.00, 0.00),
	(121, 68, 1014, 50, 90.00, 0.00),
	(122, 69, 1014, 1, 90.00, 0.00),
	(123, 70, 1014, 1, 90.00, 0.00),
	(124, 71, 1010, 1, 65.00, 0.00),
	(125, 72, 1015, 50, 100.00, 0.00),
	(126, 72, 1014, 50, 90.00, 0.00),
	(127, 73, 1010, 1, 65.00, 0.00),
	(129, 75, 1030, 6, 80.00, 480.00);

-- Volcando estructura para tabla proyecto_smorgas.tbl_fecha
CREATE TABLE IF NOT EXISTS `tbl_fecha` (
  `ID_Fecha` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Dia` tinyint(3) unsigned NOT NULL,
  `Mes` tinyint(3) unsigned NOT NULL,
  `Anio` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID_Fecha`),
  KEY `idx_fecha` (`Anio`,`Mes`,`Dia`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla proyecto_smorgas.tbl_fecha: ~6 rows (aproximadamente)
DELETE FROM `tbl_fecha`;
INSERT INTO `tbl_fecha` (`ID_Fecha`, `Dia`, `Mes`, `Anio`) VALUES
	(1, 12, 11, 2025),
	(2, 26, 11, 2025),
	(3, 5, 12, 2025),
	(6, 12, 3, 2026),
	(19, 13, 3, 2026),
	(20, 17, 3, 2026),
	(23, 14, 5, 2026);

-- Volcando estructura para tabla proyecto_smorgas.tbl_mesa
CREATE TABLE IF NOT EXISTS `tbl_mesa` (
  `ID_Mesa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Mesa` varchar(10) NOT NULL,
  PRIMARY KEY (`ID_Mesa`),
  UNIQUE KEY `ux_mesa` (`Mesa`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla proyecto_smorgas.tbl_mesa: ~9 rows (aproximadamente)
DELETE FROM `tbl_mesa`;
INSERT INTO `tbl_mesa` (`ID_Mesa`, `Mesa`) VALUES
	(100, '100'),
	(101, '101'),
	(102, '102'),
	(103, '103'),
	(104, '104'),
	(105, '105'),
	(106, '106'),
	(107, '107'),
	(108, '108');

-- Volcando estructura para tabla proyecto_smorgas.tbl_modo_entrega
CREATE TABLE IF NOT EXISTS `tbl_modo_entrega` (
  `ID_Modo_Entrega` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Modo_Entrega` varchar(40) NOT NULL,
  PRIMARY KEY (`ID_Modo_Entrega`),
  UNIQUE KEY `ux_modo` (`Modo_Entrega`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla proyecto_smorgas.tbl_modo_entrega: ~2 rows (aproximadamente)
DELETE FROM `tbl_modo_entrega`;
INSERT INTO `tbl_modo_entrega` (`ID_Modo_Entrega`, `Modo_Entrega`) VALUES
	(1, 'Comedor'),
	(2, 'Llevar');

-- Volcando estructura para tabla proyecto_smorgas.tbl_producto
CREATE TABLE IF NOT EXISTS `tbl_producto` (
  `ID_Producto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Nombre_Producto` varchar(120) NOT NULL,
  `Precio_Producto` decimal(10,2) NOT NULL DEFAULT 0.00,
  `Categoria` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`ID_Producto`),
  UNIQUE KEY `ux_producto_nombre` (`Nombre_Producto`)
) ENGINE=InnoDB AUTO_INCREMENT=1037 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla proyecto_smorgas.tbl_producto: ~37 rows (aproximadamente)
DELETE FROM `tbl_producto`;
INSERT INTO `tbl_producto` (`ID_Producto`, `Nombre_Producto`, `Precio_Producto`, `Categoria`) VALUES
	(1000, 'Huevo smorgas', 120.00, 'Especialidad'),
	(1001, 'Huevos criollos', 120.00, 'Especialidad'),
	(1002, 'Huevos ibericos', 120.00, 'Especialidad'),
	(1003, 'Huevos peninsulares', 120.00, 'Especialidad'),
	(1004, 'Omelette del chef', 120.00, 'Especialidad'),
	(1005, 'Omelette jamon y queso', 110.00, 'Especialidad'),
	(1006, 'Omelette papa y chorizo', 110.00, 'Especialidad'),
	(1007, 'Tortilla española', 120.00, 'Especialidad'),
	(1008, 'Huevos pyttipana', 150.00, 'Especialidad'),
	(1009, 'Huevos al gusto', 100.00, 'Especialidad'),
	(1010, 'Panini', 65.00, 'Sandwiches, Baguettes y Varios'),
	(1011, 'Sandwich pan blanco', 95.00, 'Sandwiches, Baguettes y Varios'),
	(1012, 'Sandwich integral', 100.00, 'Sandwiches, Baguettes y Varios'),
	(1013, 'Baguette', 100.00, 'Sandwiches, Baguettes y Varios'),
	(1014, 'Hotcakes', 90.00, 'Sandwiches, Baguettes y Varios'),
	(1015, 'Ensalada de la casa', 100.00, 'Sandwiches, Baguettes y Varios'),
	(1016, 'Burritas', 100.00, 'Sandwiches, Baguettes y Varios'),
	(1017, 'Burritas smorgas', 120.00, 'Sandwiches, Baguettes y Varios'),
	(1018, 'Paquete 1 desayuno sencillo', 150.00, 'Paquetes'),
	(1019, 'Paquete 2 desayuno completo', 180.00, 'Paquetes'),
	(1020, 'Paquete 3 desayuno sencillo de especialidad', 170.00, 'Paquetes'),
	(1021, 'Paquete 4 desayuno completo de especialidad', 200.00, 'Paquetes'),
	(1022, 'Café tipo veracruz', 40.00, 'Bebidas'),
	(1023, 'Café tipo americano', 40.00, 'Bebidas'),
	(1024, 'Café oscuro', 40.00, 'Bebidas'),
	(1025, 'Café descafeinado', 50.00, 'Bebidas'),
	(1026, 'Café tipo cubano', 60.00, 'Bebidas'),
	(1027, 'Café tipo espresso', 80.00, 'Bebidas'),
	(1028, 'Té', 30.00, 'Bebidas'),
	(1029, 'Agua de sandía', 20.00, 'Bebidas'),
	(1030, 'Agua de melón', 20.00, 'Bebidas'),
	(1031, 'Refresco embotellados', 30.00, 'Bebidas'),
	(1032, 'Vaso de leche', 25.00, 'Bebidas'),
	(1033, 'Vaso de leche c/plátano o chocolate', 30.00, 'Bebidas'),
	(1034, 'Postre del día', 25.00, 'Bebidas'),
	(1035, 'Botella de agua', 10.00, 'Bebidas'),
	(1036, 'Ingrediente extra', 20.00, 'Bebidas');

-- Volcando estructura para tabla proyecto_smorgas.tbl_usuarios
CREATE TABLE IF NOT EXISTS `tbl_usuarios` (
  `ID_Usuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Nombre_Usuario` varchar(50) NOT NULL,
  `Nombre_Usuario_norm` varchar(50) GENERATED ALWAYS AS (lcase(`Nombre_Usuario`)) STORED,
  `Rol_Usuario` varchar(20) NOT NULL,
  `Contrasenia_hash` varchar(255) NOT NULL,
  `Fecha_Creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `Session_Token` varchar(64) DEFAULT NULL,
  `Session_Expira` datetime DEFAULT NULL,
  `Ultimo_Visto` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_Usuario`),
  UNIQUE KEY `ux_usuarios_nombre_norm` (`Nombre_Usuario_norm`),
  KEY `idx_session_token` (`Session_Token`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla proyecto_smorgas.tbl_usuarios: ~19 rows (aproximadamente)
DELETE FROM `tbl_usuarios`;
INSERT INTO `tbl_usuarios` (`ID_Usuario`, `Nombre_Usuario`, `Rol_Usuario`, `Contrasenia_hash`, `Fecha_Creacion`, `Session_Token`, `Session_Expira`, `Ultimo_Visto`) VALUES
	(1, 'David', 'admin', 'scrypt:32768:8:1$h79DzQeUOmZsTtRH$824965f36dd076eb56db8e34edabc683fdeb89fef96101df14ff56a7b6ba8ad1a8a83a71910a714d890ff2393a6f910b4f4429b55375b80658934d0c9bdf1345', '2025-11-12 08:17:09', NULL, NULL, '2026-05-14 21:08:24'),
	(2, 'shirley', 'mesero', 'scrypt:32768:8:1$AntMIuIFRHa9HkLO$4b06af79a513e32f0e9eaebb6595a1638b9843446ad76c54373ac816f82f075df6dc6ec67ad78fa97d1751809e39f27f12efceedd167d65b85905d59e50d663f', '2025-11-12 08:28:02', NULL, NULL, '2025-11-12 08:30:38'),
	(5, 'Shir', 'mesero', 'scrypt:32768:8:1$QcVPsmKDUZXBardX$9920ad005652e850539ffcb6944fc3b91bcb05365bd474591427bcc98ca7b9b0064eb828b921ebae6a2b622b08e7664951da4450360d5d4593bf4aeb8d5046ad', '2025-11-12 08:31:19', NULL, NULL, '2025-11-12 08:35:06'),
	(10, 'Edelmy', 'mesero', 'scrypt:32768:8:1$6ks4wwRb2IVIDhI7$6035564de1b838b1c9a572a3dc0d58e9f982bf80e2783e5cc38d0ca210f3c3a289a7643a42dcc40f269c8464a6a8c83dd64e6466edf03131dbb37660c190c9d6', '2025-11-12 08:40:15', NULL, NULL, '2025-11-12 08:50:07'),
	(11, 'Israel', 'admin', 'scrypt:32768:8:1$Fjl7mJD3ofTrgIpd$d3c48b0e17d9328fd037d108721563e4b5fd779df69ef534dbe403505fb94505b845d5f7be745fe1186a4ea26784b603bfaa427545a22e3c2199e1e30bcb8b30', '2025-11-12 08:50:01', '871184282f139779fae849611bb4cbd5', '2025-11-12 09:20:43', '2025-11-12 08:50:43'),
	(13, 'Gabriela', 'mesero', 'scrypt:32768:8:1$OI8wC9FUS7V4kWsi$cc9470b662567bcb28fc2b8fb9d2e113ca153479ec8d8ebd3630e21d18b1d8e00aff33d052159b6c9b97948869bb14ae867a922ef6ffb917574f41e7af781026', '2025-12-05 14:00:15', NULL, NULL, '2025-12-05 14:11:30'),
	(14, 'Genesis', 'admin', 'scrypt:32768:8:1$NwM6lJhbMY84r6Hp$fe0b29ecc22923b3400ec25a466a326f4ef4072f6dccba51ea228a5e731081c63cf74eaaf5c532ff505737b0bee609e2eeeb1b43b7f641a927f31c0e9815ecbd', '2025-12-05 14:24:05', NULL, NULL, '2025-12-05 14:49:37'),
	(15, 'Fran', 'mesero', 'scrypt:32768:8:1$ZwwvGb4YLXFavnLw$65cde3ae1136c4a3227b5d3c831f3bfb34b09abebe3cfab8bd344760dc5c44d5f48858ac5525d56b9e810c01241bcad45660c12ce4d69ce4c7f66434c420e8e1', '2025-12-05 14:27:47', NULL, NULL, '2025-12-05 14:44:25'),
	(16, 'Yazmin', 'admin', 'scrypt:32768:8:1$Nx48IYlJqVY1lVVH$25c028efe0f07bf653a26fd386e422eab942536a6d9613bf6eef9a943e7d8e0cc9e6abfe918ae531ad127282d38c31e9095156c6cdb88dacafdf99140722db5c', '2025-12-05 14:50:26', NULL, NULL, '2025-12-05 14:55:25'),
	(17, 'Regina', 'mesero', 'scrypt:32768:8:1$UXdLt1ucTGZabNaj$b19238e70269b5259db1f463295948f45e91c5cb80d550bcc55b116b6f4109b73f84638d618c2f93d42b80c11ba1ecb5dba0858958d42ce218c2fa0438896364', '2025-12-05 14:55:49', NULL, NULL, NULL),
	(19, 'Nancy', 'mesero', 'scrypt:32768:8:1$xCszfbr7FW9gxj2M$9a73dead5d030fa1c967d8fa2aaf51173f762e16e85ded0572c73525a712acdf7232ebaa012bc4e03739134329f19dbc5b763659199b0fb0e700e16d61abb51a', '2025-12-05 14:56:34', NULL, NULL, '2025-12-05 15:00:53'),
	(20, 'keller', 'admin', 'scrypt:32768:8:1$0kiJixdgqLz4uNTQ$562d016694ff43268bee04a4520deffacd17471f03e8d1d45e6b1c520869f8211d7b917d5d31ff9911fee11848eaa40187b136d7358619d516645b620bffa0ba', '2025-12-05 15:03:06', NULL, NULL, '2025-12-05 15:12:46'),
	(21, 'dani', 'admin', 'scrypt:32768:8:1$th9qB3WYbNSre9Zs$944bf82972500ebf8e5831801275afa04c00a3bdf08ccc1749348f4c4f6f945f29ba66112caa1bf8bc9a50c1896df16ef8adf5bcdc5d01559e89c65575367db1', '2025-12-05 15:25:12', '579f1e94b54895ca984824fa8b010f8c', '2025-12-05 15:55:19', '2025-12-05 15:25:19'),
	(22, 'Prueba', 'admin', 'scrypt:32768:8:1$hTwKyoXl685ALatW$673681b28c786966594718ed6467a39f490e88e4fc33ec8fdf0a0065ae1951d41a2ff8a92c0659b3af28613e9ef27ffac7c3fc5e15f41fd24317d8f89e068fcf', '2026-03-12 10:21:10', NULL, NULL, NULL),
	(23, 'INTENTO', 'admin', 'scrypt:32768:8:1$mjFQS6gr7GZFhpOU$1ceca6caa943e96bd31b006226340376da58e30824d1b6ddd962ff806e97980a614f8003b7a38bdb00a363c1eac22bda398827ec2ac177b743eeefb0446e6f2e', '2026-03-12 11:54:10', NULL, NULL, NULL),
	(24, 'INI', 'admin', 'scrypt:32768:8:1$yV9dWaPNfrYDLr6X$34ff7996e700c8d4b220f97f2bf2efc2a01d03395483242d03618dfb1d1074d70369641288cc3fbb5e5e06d9d31dccab9faebac8c5d06407014fd11d6b8a3d19', '2026-03-13 13:11:16', 'd78258b7d98749e299edae896e831abb', '2026-03-17 17:02:45', '2026-03-17 16:32:45'),
	(25, 'Caro', 'admin', 'scrypt:32768:8:1$aBAdM3NZCzi6WMK5$da1fae6ec08cc90d07268e4ac798c865c7b61a0577d609c1d5f2138831e590d325793bdc18a108f2ca96d1d3fe50b2dfa3070c52700d15ba202d444571439682', '2026-03-17 16:14:59', '71ff1bad51bb08e36f5fc7ab214819f4', '2026-03-17 17:00:48', '2026-03-17 16:30:48'),
	(26, 'Silvestre', 'mesero', 'scrypt:32768:8:1$cuZ27CpZs8ccWM6g$4fd214b1a2ccda2760f9812aea3871d7df722a2423b48ca3ce4792546307e668c96a4584daee901ce55d764a0f4a49e663c0817a1ed66a943502397cd01ef769', '2026-03-17 16:38:17', '533c0d3efe4165fd5724e6336a38e9d7', '2026-03-17 17:11:05', '2026-03-17 16:41:05');

-- Volcando estructura para disparador proyecto_smorgas.trg_detalle_after_delete
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER trg_detalle_after_delete
AFTER DELETE ON tbl_detalle
FOR EACH ROW
BEGIN
    UPDATE tbl_compra
       SET Importe_Total  = (SELECT COALESCE(SUM(Cantidad * Precio_Unit), 0)
                               FROM tbl_detalle WHERE Folio = OLD.Folio),
           Cantidad_Total = (SELECT COALESCE(SUM(Cantidad), 0)
                               FROM tbl_detalle WHERE Folio = OLD.Folio)
     WHERE Folio = OLD.Folio;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador proyecto_smorgas.trg_detalle_after_insert
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER trg_detalle_after_insert
AFTER INSERT ON tbl_detalle
FOR EACH ROW
BEGIN
    -- Solo actualiza la cabecera (no toca tbl_detalle)
    UPDATE tbl_compra
       SET Importe_Total  = (SELECT COALESCE(SUM(Cantidad * Precio_Unit), 0)
                               FROM tbl_detalle WHERE Folio = NEW.Folio),
           Cantidad_Total = (SELECT COALESCE(SUM(Cantidad), 0)
                               FROM tbl_detalle WHERE Folio = NEW.Folio)
     WHERE Folio = NEW.Folio;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador proyecto_smorgas.trg_detalle_after_update
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER trg_detalle_after_update
AFTER UPDATE ON tbl_detalle
FOR EACH ROW
BEGIN
    UPDATE tbl_compra
       SET Importe_Total  = (SELECT COALESCE(SUM(Cantidad * Precio_Unit), 0)
                               FROM tbl_detalle WHERE Folio = NEW.Folio),
           Cantidad_Total = (SELECT COALESCE(SUM(Cantidad), 0)
                               FROM tbl_detalle WHERE Folio = NEW.Folio)
     WHERE Folio = NEW.Folio;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
